"""Seed the database with a demo admin, a demo user and a sample fleet.

Usage:  python seed.py
Demo logins:  admin@dealership.com / Admin123!   and   user@dealership.com / User1234!
"""
from sqlalchemy import select

from app import models, schemas
from app.database import Base, SessionLocal, engine
from app.services import auth_service, vehicle_service

IMG = "https://images.unsplash.com/"
FLEET = [
    ("Toyota", "Camry", "Sedan", 28000, 5, "photo-1621007947382-bb3c3994e3fb?w=800"),
    ("Honda", "Civic", "Sedan", 24500, 8, "photo-1606611013016-969c19ba27bb?w=800"),
    ("Tesla", "Model 3", "Electric", 42990, 3, "photo-1560958089-b8a1929cea89?w=800"),
    ("Ford", "F-150", "Truck", 45500, 4, "photo-1590362891991-f776e747a588?w=800"),
    ("Toyota", "RAV4", "SUV", 35200, 6, "photo-1568844293986-8d0400bd4745?w=800"),
    ("BMW", "M4", "Coupe", 78900, 1, "photo-1617814076367-b759c7d7e738?w=800"),
    ("Jeep", "Wrangler", "SUV", 41800, 0, "photo-1533473359331-0135ef1b58bf?w=800"),
    ("Hyundai", "Ioniq 5", "Electric", 43650, 2, "photo-1606016159991-dfe4f2746ad5?w=800"),
]


def main() -> None:
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if db.scalar(select(models.User.id).limit(1)) is None:
            auth_service.register_user(db, schemas.UserCreate(email="admin@dealership.com", username="Admin", password="Admin123!"))
            auth_service.register_user(db, schemas.UserCreate(email="user@dealership.com", username="Demo User", password="User1234!"))
        if db.scalar(select(models.Vehicle.id).limit(1)) is None:
            for make, model, cat, price, qty, img in FLEET:
                vehicle_service.create_vehicle(
                    db, schemas.VehicleCreate(make=make, model=model, category=cat, price=price, quantity=qty, image_url=IMG + img)
                )
    print("Database seeded.")


if __name__ == "__main__":
    main()
