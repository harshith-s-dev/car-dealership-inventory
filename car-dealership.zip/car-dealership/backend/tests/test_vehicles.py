"""Vehicle CRUD tests (TDD red phase)."""


def create(client, headers, data):
    return client.post("/api/vehicles", json=data, headers=headers)


def test_create_vehicle(client, user_headers, sample_vehicle):
    r = create(client, user_headers, sample_vehicle)
    assert r.status_code == 201
    body = r.json()
    assert body["id"] and body["make"] == "Toyota" and body["quantity"] == 5


def test_create_requires_auth(client, sample_vehicle):
    assert client.post("/api/vehicles", json=sample_vehicle).status_code == 401


def test_create_validates_input(client, user_headers, sample_vehicle):
    assert create(client, user_headers, {**sample_vehicle, "price": -1}).status_code == 422
    assert create(client, user_headers, {**sample_vehicle, "quantity": -3}).status_code == 422
    assert create(client, user_headers, {**sample_vehicle, "make": ""}).status_code == 422
    bad = {k: v for k, v in sample_vehicle.items() if k != "model"}
    assert create(client, user_headers, bad).status_code == 422


def test_list_returns_all_vehicles_including_sold_out(client, user_headers, sample_vehicle):
    create(client, user_headers, sample_vehicle)
    create(client, user_headers, {**sample_vehicle, "model": "Corolla", "quantity": 0})
    r = client.get("/api/vehicles", headers=user_headers)
    assert r.status_code == 200 and len(r.json()) == 2


def test_list_available_only_filter(client, user_headers, sample_vehicle):
    create(client, user_headers, sample_vehicle)
    create(client, user_headers, {**sample_vehicle, "model": "Corolla", "quantity": 0})
    r = client.get("/api/vehicles?available_only=true", headers=user_headers)
    assert [v["model"] for v in r.json()] == ["Camry"]


def test_get_single_vehicle_and_404(client, user_headers, sample_vehicle):
    vid = create(client, user_headers, sample_vehicle).json()["id"]
    assert client.get(f"/api/vehicles/{vid}", headers=user_headers).json()["model"] == "Camry"
    assert client.get("/api/vehicles/9999", headers=user_headers).status_code == 404


def test_update_vehicle_partial(client, user_headers, sample_vehicle):
    vid = create(client, user_headers, sample_vehicle).json()["id"]
    r = client.put(f"/api/vehicles/{vid}", json={"price": 26500}, headers=user_headers)
    assert r.status_code == 200
    assert r.json()["price"] == 26500 and r.json()["make"] == "Toyota"


def test_update_missing_vehicle_404(client, user_headers):
    assert client.put("/api/vehicles/42", json={"price": 1}, headers=user_headers).status_code == 404


def test_update_rejects_invalid(client, user_headers, sample_vehicle):
    vid = create(client, user_headers, sample_vehicle).json()["id"]
    assert client.put(f"/api/vehicles/{vid}", json={"price": -5}, headers=user_headers).status_code == 422


def test_delete_admin_only(client, admin_headers, user_headers, sample_vehicle):
    vid = create(client, admin_headers, sample_vehicle).json()["id"]
    assert client.delete(f"/api/vehicles/{vid}", headers=user_headers).status_code == 403
    assert client.delete(f"/api/vehicles/{vid}", headers=admin_headers).status_code == 204
    assert client.get(f"/api/vehicles/{vid}", headers=admin_headers).status_code == 404


def test_delete_missing_404(client, admin_headers):
    assert client.delete("/api/vehicles/777", headers=admin_headers).status_code == 404
