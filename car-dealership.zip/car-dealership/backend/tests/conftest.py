"""Shared fixtures: each test gets a fresh on-disk-style SQLite DB (StaticPool, isolated)."""
import os

os.environ.setdefault("BCRYPT_ROUNDS", "4")  # fast hashing in tests

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db, make_engine
from app.main import app


@pytest.fixture()
def client():
    from sqlalchemy import create_engine

    engine = create_engine(
        "sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
    )
    Base.metadata.create_all(engine)
    TestingSession = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)

    def override_get_db():
        db = TestingSession()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def _register_and_login(client, email, password="Passw0rd!"):
    client.post("/api/auth/register", json={"email": email, "username": email.split("@")[0], "password": password})
    r = client.post("/api/auth/login", json={"email": email, "password": password})
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture()
def admin_headers(client):
    """The first registered user becomes admin."""
    return _register_and_login(client, "admin@example.com")


@pytest.fixture()
def user_headers(client, admin_headers):  # depends on admin so this one is a normal user
    return _register_and_login(client, "user@example.com")


@pytest.fixture()
def sample_vehicle():
    return {"make": "Toyota", "model": "Camry", "category": "Sedan", "price": 28000, "quantity": 5}
