"""Auth endpoint tests (written first - TDD red phase)."""

REG = {"email": "jane@example.com", "username": "jane", "password": "Passw0rd!"}


def test_register_creates_user(client):
    r = client.post("/api/auth/register", json=REG)
    assert r.status_code == 201
    body = r.json()
    assert body["email"] == REG["email"]
    assert "password" not in body and "hashed_password" not in body


def test_first_user_is_admin_second_is_user(client):
    assert client.post("/api/auth/register", json=REG).json()["role"] == "admin"
    other = {**REG, "email": "bob@example.com"}
    assert client.post("/api/auth/register", json=other).json()["role"] == "user"


def test_register_duplicate_email_conflicts(client):
    client.post("/api/auth/register", json=REG)
    assert client.post("/api/auth/register", json=REG).status_code == 409


def test_register_rejects_short_password_and_bad_email(client):
    assert client.post("/api/auth/register", json={**REG, "password": "abc"}).status_code == 422
    assert client.post("/api/auth/register", json={**REG, "email": "nope"}).status_code == 422


def test_login_returns_token(client):
    client.post("/api/auth/register", json=REG)
    r = client.post("/api/auth/login", json={"email": REG["email"], "password": REG["password"]})
    assert r.status_code == 200
    assert r.json()["token_type"] == "bearer" and r.json()["access_token"]
    assert r.json()["user"]["email"] == REG["email"]


def test_login_wrong_password_unauthorized(client):
    client.post("/api/auth/register", json=REG)
    r = client.post("/api/auth/login", json={"email": REG["email"], "password": "wrongpass1"})
    assert r.status_code == 401


def test_login_unknown_user_unauthorized(client):
    r = client.post("/api/auth/login", json={"email": "ghost@example.com", "password": "whatever1"})
    assert r.status_code == 401


def test_protected_route_requires_token(client):
    assert client.get("/api/vehicles").status_code == 401
    assert client.get("/api/vehicles", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_me_returns_current_user(client, admin_headers):
    r = client.get("/api/auth/me", headers=admin_headers)
    assert r.status_code == 200 and r.json()["email"] == "admin@example.com"


def test_health(client):
    assert client.get("/api/health").json() == {"status": "ok"}
