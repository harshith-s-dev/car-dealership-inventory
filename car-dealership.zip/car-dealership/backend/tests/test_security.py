"""Unit tests for password hashing and token helpers."""
import jwt
import pytest

from app import security
from app.config import settings


def test_hash_is_salted_and_verifiable():
    h1, h2 = security.hash_password("secret123"), security.hash_password("secret123")
    assert h1 != h2
    assert security.verify_password("secret123", h1)
    assert not security.verify_password("other", h1)


def test_verify_handles_malformed_hash():
    assert security.verify_password("x", "not-a-hash") is False


def test_token_roundtrip():
    token = security.create_access_token(7, "admin")
    payload = security.decode_access_token(token)
    assert payload["sub"] == "7" and payload["role"] == "admin"


def test_tampered_or_expired_token_rejected(monkeypatch):
    token = security.create_access_token(1, "user")
    with pytest.raises(jwt.PyJWTError):
        security.decode_access_token(token + "x")
    monkeypatch.setattr(settings, "ACCESS_TOKEN_EXPIRE_MINUTES", -1)
    with pytest.raises(jwt.PyJWTError):
        security.decode_access_token(security.create_access_token(1, "user"))
