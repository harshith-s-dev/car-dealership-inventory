"""Purchase / restock tests (TDD red phase)."""
import pytest


@pytest.fixture()
def vehicle_id(client, admin_headers, sample_vehicle):
    return client.post("/api/vehicles", json=sample_vehicle, headers=admin_headers).json()["id"]


def test_purchase_decrements_quantity(client, user_headers, vehicle_id):
    r = client.post(f"/api/vehicles/{vehicle_id}/purchase", headers=user_headers)
    assert r.status_code == 200 and r.json()["quantity"] == 4


def test_purchase_multiple_units(client, user_headers, vehicle_id):
    r = client.post(f"/api/vehicles/{vehicle_id}/purchase", json={"quantity": 3}, headers=user_headers)
    assert r.json()["quantity"] == 2


def test_purchase_more_than_stock_conflicts_and_changes_nothing(client, user_headers, vehicle_id):
    r = client.post(f"/api/vehicles/{vehicle_id}/purchase", json={"quantity": 6}, headers=user_headers)
    assert r.status_code == 409
    assert client.get(f"/api/vehicles/{vehicle_id}", headers=user_headers).json()["quantity"] == 5


def test_purchase_out_of_stock_conflicts(client, user_headers, vehicle_id):
    client.post(f"/api/vehicles/{vehicle_id}/purchase", json={"quantity": 5}, headers=user_headers)
    r = client.post(f"/api/vehicles/{vehicle_id}/purchase", headers=user_headers)
    assert r.status_code == 409


def test_purchase_missing_vehicle_404(client, user_headers):
    assert client.post("/api/vehicles/999/purchase", headers=user_headers).status_code == 404


def test_purchase_requires_auth(client, vehicle_id):
    assert client.post(f"/api/vehicles/{vehicle_id}/purchase").status_code == 401


def test_purchase_rejects_non_positive_quantity(client, user_headers, vehicle_id):
    r = client.post(f"/api/vehicles/{vehicle_id}/purchase", json={"quantity": 0}, headers=user_headers)
    assert r.status_code == 422


def test_restock_admin_increments(client, admin_headers, vehicle_id):
    r = client.post(f"/api/vehicles/{vehicle_id}/restock", json={"quantity": 10}, headers=admin_headers)
    assert r.status_code == 200 and r.json()["quantity"] == 15


def test_restock_forbidden_for_regular_user(client, user_headers, vehicle_id):
    r = client.post(f"/api/vehicles/{vehicle_id}/restock", json={"quantity": 10}, headers=user_headers)
    assert r.status_code == 403


def test_restock_missing_vehicle_404(client, admin_headers):
    assert client.post("/api/vehicles/999/restock", json={"quantity": 1}, headers=admin_headers).status_code == 404


def test_restock_rejects_invalid_quantity(client, admin_headers, vehicle_id):
    assert client.post(f"/api/vehicles/{vehicle_id}/restock", json={"quantity": -2}, headers=admin_headers).status_code == 422
