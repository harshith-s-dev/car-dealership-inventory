"""Vehicle search tests (TDD red phase)."""
import pytest

FLEET = [
    {"make": "Toyota", "model": "Camry", "category": "Sedan", "price": 28000, "quantity": 5},
    {"make": "Toyota", "model": "RAV4", "category": "SUV", "price": 35000, "quantity": 2},
    {"make": "Honda", "model": "Civic", "category": "Sedan", "price": 24000, "quantity": 0},
    {"make": "Ford", "model": "F-150", "category": "Truck", "price": 45000, "quantity": 3},
]


@pytest.fixture()
def seeded(client, user_headers):
    for v in FLEET:
        client.post("/api/vehicles", json=v, headers=user_headers)
    return user_headers


def search(client, headers, **params):
    r = client.get("/api/vehicles/search", params=params, headers=headers)
    assert r.status_code == 200, r.text
    return sorted(v["model"] for v in r.json())


def test_search_requires_auth(client):
    assert client.get("/api/vehicles/search").status_code == 401


def test_no_filters_returns_everything(client, seeded):
    assert len(search(client, seeded)) == 4


def test_search_by_make_case_insensitive(client, seeded):
    assert search(client, seeded, make="toyota") == ["Camry", "RAV4"]


def test_search_by_model_partial(client, seeded):
    assert search(client, seeded, model="civ") == ["Civic"]


def test_search_by_category(client, seeded):
    assert search(client, seeded, category="sedan") == ["Camry", "Civic"]


def test_search_by_price_range(client, seeded):
    assert search(client, seeded, min_price=25000, max_price=40000) == ["Camry", "RAV4"]
    assert search(client, seeded, min_price=40000) == ["F-150"]
    assert search(client, seeded, max_price=24000) == ["Civic"]


def test_search_combined_filters(client, seeded):
    assert search(client, seeded, make="Toyota", category="SUV") == ["RAV4"]


def test_search_no_match_returns_empty(client, seeded):
    assert search(client, seeded, make="Tesla") == []


def test_search_invalid_price_range_rejected(client, seeded):
    r = client.get("/api/vehicles/search", params={"min_price": 50000, "max_price": 1000}, headers=seeded)
    assert r.status_code == 422


def test_search_treats_like_wildcards_literally(client, seeded):
    assert search(client, seeded, make="%") == []
