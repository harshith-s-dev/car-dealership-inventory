"""Vehicle & inventory business logic, kept independent of HTTP concerns."""
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .. import models, schemas


class VehicleNotFound(Exception):
    pass


class InsufficientStock(Exception):
    def __init__(self, available: int):
        self.available = available


def list_vehicles(db: Session, available_only: bool = False) -> list[models.Vehicle]:
    stmt = select(models.Vehicle).order_by(models.Vehicle.id)
    if available_only:
        stmt = stmt.where(models.Vehicle.quantity > 0)
    return list(db.scalars(stmt))


def get_vehicle(db: Session, vehicle_id: int) -> models.Vehicle:
    vehicle = db.get(models.Vehicle, vehicle_id)
    if vehicle is None:
        raise VehicleNotFound(vehicle_id)
    return vehicle


def create_vehicle(db: Session, data: schemas.VehicleCreate) -> models.Vehicle:
    vehicle = models.Vehicle(**data.model_dump())
    db.add(vehicle)
    db.commit()
    return vehicle


def update_vehicle(db: Session, vehicle_id: int, data: schemas.VehicleUpdate) -> models.Vehicle:
    vehicle = get_vehicle(db, vehicle_id)
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(vehicle, field, value)
    db.commit()
    return vehicle


def delete_vehicle(db: Session, vehicle_id: int) -> None:
    db.delete(get_vehicle(db, vehicle_id))
    db.commit()


def _contains(column, term: str):
    """Case-insensitive substring match with LIKE wildcards escaped."""
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return column.ilike(f"%{escaped}%", escape="\\")


def search_vehicles(
    db: Session,
    make: str | None = None,
    model: str | None = None,
    category: str | None = None,
    min_price: float | None = None,
    max_price: float | None = None,
) -> list[models.Vehicle]:
    stmt = select(models.Vehicle).order_by(models.Vehicle.id)
    if make:
        stmt = stmt.where(_contains(models.Vehicle.make, make))
    if model:
        stmt = stmt.where(_contains(models.Vehicle.model, model))
    if category:
        stmt = stmt.where(_contains(models.Vehicle.category, category))
    if min_price is not None:
        stmt = stmt.where(models.Vehicle.price >= min_price)
    if max_price is not None:
        stmt = stmt.where(models.Vehicle.price <= max_price)
    return list(db.scalars(stmt))


def purchase_vehicle(db: Session, vehicle_id: int, quantity: int = 1) -> models.Vehicle:
    """Atomically decrement stock; the conditional UPDATE prevents overselling under concurrency."""
    vehicle = get_vehicle(db, vehicle_id)
    result = db.execute(
        update(models.Vehicle)
        .where(models.Vehicle.id == vehicle_id, models.Vehicle.quantity >= quantity)
        .values(quantity=models.Vehicle.quantity - quantity)
    )
    if result.rowcount == 0:
        db.rollback()
        raise InsufficientStock(vehicle.quantity)
    db.commit()
    db.refresh(vehicle)
    return vehicle


def restock_vehicle(db: Session, vehicle_id: int, quantity: int) -> models.Vehicle:
    vehicle = get_vehicle(db, vehicle_id)
    db.execute(
        update(models.Vehicle)
        .where(models.Vehicle.id == vehicle_id)
        .values(quantity=models.Vehicle.quantity + quantity)
    )
    db.commit()
    db.refresh(vehicle)
    return vehicle
