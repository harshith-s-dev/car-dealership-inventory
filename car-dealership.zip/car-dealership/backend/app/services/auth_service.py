"""User registration / authentication business logic."""
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import models, schemas
from ..security import hash_password, verify_password


class EmailAlreadyRegistered(Exception):
    pass


class InvalidCredentials(Exception):
    pass


def register_user(db: Session, data: schemas.UserCreate) -> models.User:
    email = data.email.lower()
    if db.scalar(select(models.User).where(models.User.email == email)):
        raise EmailAlreadyRegistered(email)
    is_first = db.scalar(select(func.count(models.User.id))) == 0
    user = models.User(
        email=email,
        username=data.username,
        hashed_password=hash_password(data.password),
        role="admin" if is_first else "user",  # bootstrap: first account is the admin
    )
    db.add(user)
    db.commit()
    return user


def authenticate(db: Session, email: str, password: str) -> models.User:
    user = db.scalar(select(models.User).where(models.User.email == email.lower()))
    if not user or not verify_password(password, user.hashed_password):
        raise InvalidCredentials()
    return user
