"""Application settings, read from environment variables with safe defaults."""
import os


class Settings:
    """Runtime configuration. Override with environment variables."""

    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./dealership.db")
    JWT_SECRET: str = os.getenv("JWT_SECRET", "dev-secret-change-me-in-production-32b")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))
    BCRYPT_ROUNDS: int = int(os.getenv("BCRYPT_ROUNDS", "12"))
    CORS_ORIGINS: list[str] = os.getenv(
        "CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
    ).split(",")


settings = Settings()
