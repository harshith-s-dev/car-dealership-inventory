from fastapi import APIRouter, Body, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from .. import schemas
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..services import vehicle_service as svc

router = APIRouter(prefix="/api/vehicles", tags=["vehicles"], dependencies=[Depends(get_current_user)])


def _not_found():
    return HTTPException(status.HTTP_404_NOT_FOUND, "Vehicle not found")


@router.post("", response_model=schemas.VehicleOut, status_code=status.HTTP_201_CREATED)
def add_vehicle(data: schemas.VehicleCreate, db: Session = Depends(get_db)):
    return svc.create_vehicle(db, data)


@router.get("", response_model=list[schemas.VehicleOut])
def list_vehicles(available_only: bool = False, db: Session = Depends(get_db)):
    return svc.list_vehicles(db, available_only)


@router.get("/search", response_model=list[schemas.VehicleOut])
def search_vehicles(
    make: str | None = None,
    model: str | None = None,
    category: str | None = None,
    min_price: float | None = Query(default=None, ge=0),
    max_price: float | None = Query(default=None, ge=0),
    db: Session = Depends(get_db),
):
    if min_price is not None and max_price is not None and min_price > max_price:
        raise HTTPException(422, "min_price cannot exceed max_price")
    return svc.search_vehicles(db, make, model, category, min_price, max_price)


@router.get("/{vehicle_id}", response_model=schemas.VehicleOut)
def get_vehicle(vehicle_id: int, db: Session = Depends(get_db)):
    try:
        return svc.get_vehicle(db, vehicle_id)
    except svc.VehicleNotFound:
        raise _not_found()


@router.put("/{vehicle_id}", response_model=schemas.VehicleOut)
def update_vehicle(vehicle_id: int, data: schemas.VehicleUpdate, db: Session = Depends(get_db)):
    try:
        return svc.update_vehicle(db, vehicle_id, data)
    except svc.VehicleNotFound:
        raise _not_found()


@router.delete("/{vehicle_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(require_admin)])
def delete_vehicle(vehicle_id: int, db: Session = Depends(get_db)):
    try:
        svc.delete_vehicle(db, vehicle_id)
    except svc.VehicleNotFound:
        raise _not_found()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/{vehicle_id}/purchase", response_model=schemas.VehicleOut)
def purchase_vehicle(
    vehicle_id: int,
    data: schemas.QuantityChange = Body(default_factory=schemas.QuantityChange),
    db: Session = Depends(get_db),
):
    try:
        return svc.purchase_vehicle(db, vehicle_id, data.quantity)
    except svc.VehicleNotFound:
        raise _not_found()
    except svc.InsufficientStock as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, f"Insufficient stock (available: {exc.available})")


@router.post("/{vehicle_id}/restock", response_model=schemas.VehicleOut, dependencies=[Depends(require_admin)])
def restock_vehicle(vehicle_id: int, data: schemas.QuantityChange, db: Session = Depends(get_db)):
    try:
        return svc.restock_vehicle(db, vehicle_id, data.quantity)
    except svc.VehicleNotFound:
        raise _not_found()
