"""Car Dealership Inventory System - backend package."""
