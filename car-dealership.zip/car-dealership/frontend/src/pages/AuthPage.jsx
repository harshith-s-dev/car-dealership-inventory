import { useState } from "react";
import Logo from "../components/Logo";
import { useAuth } from "../context/AuthContext";

export default function AuthPage() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ email: "", username: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const isLogin = mode === "login";

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      if (isLogin) await login(form.email, form.password);
      else await register(form.email, form.username, form.password);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen lg:grid-cols-2">
      <section className="relative hidden flex-col justify-between overflow-hidden p-12 lg:flex">
        <Logo />
        <div className="max-w-md animate-rise">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[.25em] text-accent">Inventory system</p>
          <h1 className="font-display text-5xl font-bold leading-[1.05] text-white">Every car.<br />Every count.<br />Always in sync.</h1>
          <p className="mt-5 text-slate-400">Browse the live showroom, search by make, model or budget, and keep stock accurate to the last unit.</p>
        </div>
        <p className="text-xs text-slate-500">© {new Date().getFullYear()} Apex Motors</p>
      </section>

      <section className="flex items-center justify-center p-6">
        <form onSubmit={submit} className="w-full max-w-sm animate-rise rounded-2xl border border-ink-700 bg-ink-900/80 p-8 shadow-2xl backdrop-blur" aria-label={isLogin ? "Login form" : "Registration form"}>
          <Logo className="mb-6 lg:hidden" />
          <h2 className="font-display text-2xl font-bold text-white">{isLogin ? "Welcome back" : "Create your account"}</h2>
          <p className="mb-6 mt-1 text-sm text-slate-400">{isLogin ? "Sign in to manage the showroom." : "The first account registered becomes the admin."}</p>

          <div className="space-y-4">
            {!isLogin && (
              <div>
                <label className="label" htmlFor="username">Name</label>
                <input id="username" className="input" required minLength={2} value={form.username} onChange={set("username")} placeholder="Jane Doe" />
              </div>
            )}
            <div>
              <label className="label" htmlFor="email">Email</label>
              <input id="email" type="email" className="input" required value={form.email} onChange={set("email")} placeholder="you@example.com" autoComplete="email" />
            </div>
            <div>
              <label className="label" htmlFor="password">Password</label>
              <input id="password" type="password" className="input" required minLength={isLogin ? 1 : 8} value={form.password} onChange={set("password")} placeholder={isLogin ? "••••••••" : "At least 8 characters"} autoComplete={isLogin ? "current-password" : "new-password"} />
            </div>
          </div>

          {error && <p role="alert" className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}

          <button className="btn-primary mt-6 w-full" disabled={busy}>{busy ? "Please wait…" : isLogin ? "Sign in" : "Create account"}</button>
          <p className="mt-5 text-center text-sm text-slate-400">
            {isLogin ? "New here?" : "Already registered?"}{" "}
            <button type="button" className="font-semibold text-accent hover:underline" onClick={() => { setMode(isLogin ? "register" : "login"); setError(""); }}>
              {isLogin ? "Create an account" : "Sign in"}
            </button>
          </p>
        </form>
      </section>
    </main>
  );
}
