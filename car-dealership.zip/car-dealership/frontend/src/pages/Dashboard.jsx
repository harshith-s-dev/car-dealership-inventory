import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import FilterBar, { EMPTY_FILTERS } from "../components/FilterBar";
import Logo from "../components/Logo";
import { ConfirmDialog, QuantityDialog } from "../components/Modals";
import Toast from "../components/Toast";
import VehicleCard from "../components/VehicleCard";
import VehicleFormModal from "../components/VehicleFormModal";
import { useAuth } from "../context/AuthContext";
import { api } from "../lib/api";

export default function Dashboard() {
  const { user, isAdmin, logout } = useAuth();
  const [vehicles, setVehicles] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [toast, setToast] = useState(null);
  const [dialog, setDialog] = useState(null); // {type, vehicle?}
  const [busyId, setBusyId] = useState(null);
  const toastTimer = useRef();

  const notify = useCallback((message, type = "success") => {
    setToast({ message, type });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3500);
  }, []);

  // Category options come from the full inventory, independent of active filters.
  const loadCategories = useCallback(() => {
    api.listVehicles().then((all) => setCategories([...new Set(all.map((v) => v.category))].sort())).catch(() => {});
  }, []);

  const hasFilters = useMemo(() => Object.values(filters).some(Boolean), [filters]);

  const load = useCallback(async () => {
    try {
      setError("");
      setVehicles(hasFilters ? await api.searchVehicles(filters) : await api.listVehicles());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [filters, hasFilters]);

  useEffect(() => {
    const t = setTimeout(load, 250); // debounce typing
    return () => clearTimeout(t);
  }, [load]);
  useEffect(loadCategories, [loadCategories]);

  const refresh = () => { load(); loadCategories(); };
  const close = () => setDialog(null);

  async function run(fn, successMsg, id) {
    setBusyId(id ?? null);
    try {
      await fn();
      notify(successMsg);
      refresh();
      close();
    } catch (e) {
      notify(e.message, "error");
      refresh();
    } finally {
      setBusyId(null);
    }
  }

  const inStock = vehicles.reduce((n, v) => n + v.quantity, 0);

  return (
    <div className="mx-auto max-w-7xl px-4 pb-20 sm:px-6">
      <header className="flex flex-wrap items-center justify-between gap-4 py-6">
        <Logo />
        <div className="flex items-center gap-3">
          <div className="text-right text-sm">
            <p className="font-medium text-white">{user.username}</p>
            <p className="text-xs uppercase tracking-wider text-slate-400">{isAdmin ? "Admin" : "Customer"}</p>
          </div>
          <button className="btn-ghost" onClick={logout}>Log out</button>
        </div>
      </header>

      <section className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-white sm:text-4xl">Showroom</h1>
          <p className="mt-1 text-sm text-slate-400">{vehicles.length} models · {inStock} units in stock</p>
        </div>
        {isAdmin && <button className="btn-primary" onClick={() => setDialog({ type: "form" })}>+ Add vehicle</button>}
      </section>

      <FilterBar filters={filters} categories={categories} onChange={setFilters} onReset={() => setFilters(EMPTY_FILTERS)} />

      <div className="mt-6">
        {error && <p role="alert" className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-red-300">{error}</p>}
        {loading ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-80 animate-pulse rounded-2xl bg-ink-800" />)}
          </div>
        ) : vehicles.length === 0 && !error ? (
          <div className="rounded-2xl border border-dashed border-ink-600 py-20 text-center">
            <p className="font-display text-xl text-white">No vehicles found</p>
            <p className="mt-1 text-sm text-slate-400">{hasFilters ? "Try loosening your filters." : "The showroom is empty."}</p>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {vehicles.map((v, i) => (
              <VehicleCard key={v.id} vehicle={v} index={i} isAdmin={isAdmin} busy={busyId === v.id}
                onPurchase={(veh) => setDialog({ type: "purchase", vehicle: veh })}
                onRestock={(veh) => setDialog({ type: "restock", vehicle: veh })}
                onEdit={(veh) => setDialog({ type: "form", vehicle: veh })}
                onDelete={(veh) => setDialog({ type: "delete", vehicle: veh })} />
            ))}
          </div>
        )}
      </div>

      {dialog?.type === "form" && (
        <VehicleFormModal vehicle={dialog.vehicle} onClose={close}
          onSubmit={async (data) => {
            if (dialog.vehicle) await api.updateVehicle(dialog.vehicle.id, data);
            else await api.createVehicle(data);
            notify(dialog.vehicle ? "Vehicle updated" : "Vehicle added");
            refresh(); close();
          }} />
      )}
      {dialog?.type === "purchase" && (
        <QuantityDialog title={`Purchase ${dialog.vehicle.make} ${dialog.vehicle.model}`} message={`${dialog.vehicle.quantity} available. How many would you like?`} max={dialog.vehicle.quantity} confirmLabel="Confirm purchase" onClose={close}
          onConfirm={(q) => run(() => api.purchase(dialog.vehicle.id, q), `Purchased ${q} × ${dialog.vehicle.model}`, dialog.vehicle.id)} />
      )}
      {dialog?.type === "restock" && (
        <QuantityDialog title={`Restock ${dialog.vehicle.make} ${dialog.vehicle.model}`} message="How many units are arriving?" confirmLabel="Add stock" onClose={close}
          onConfirm={(q) => run(() => api.restock(dialog.vehicle.id, q), `Restocked +${q} ${dialog.vehicle.model}`, dialog.vehicle.id)} />
      )}
      {dialog?.type === "delete" && (
        <ConfirmDialog danger title="Delete vehicle?" message={`${dialog.vehicle.make} ${dialog.vehicle.model} will be permanently removed from inventory.`} confirmLabel="Delete" onClose={close}
          onConfirm={() => run(() => api.deleteVehicle(dialog.vehicle.id), "Vehicle deleted", dialog.vehicle.id)} />
      )}

      <Toast toast={toast} onClose={() => setToast(null)} />
    </div>
  );
}
