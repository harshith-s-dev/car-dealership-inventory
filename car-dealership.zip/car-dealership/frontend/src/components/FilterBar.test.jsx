import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import FilterBar, { EMPTY_FILTERS } from "./FilterBar";

describe("FilterBar", () => {
  it("emits updated filters on typing", async () => {
    const onChange = vi.fn();
    render(<FilterBar filters={EMPTY_FILTERS} categories={["SUV"]} onChange={onChange} onReset={() => {}} />);
    await userEvent.type(screen.getByLabelText("Make"), "T");
    expect(onChange).toHaveBeenCalledWith({ ...EMPTY_FILTERS, make: "T" });
  });

  it("clear button is disabled until a filter is active, then resets", async () => {
    const onReset = vi.fn();
    const { rerender } = render(<FilterBar filters={EMPTY_FILTERS} categories={[]} onChange={() => {}} onReset={onReset} />);
    expect(screen.getByRole("button", { name: /clear/i })).toBeDisabled();
    rerender(<FilterBar filters={{ ...EMPTY_FILTERS, make: "Ford" }} categories={[]} onChange={() => {}} onReset={onReset} />);
    await userEvent.click(screen.getByRole("button", { name: /clear/i }));
    expect(onReset).toHaveBeenCalled();
  });
});
