export default function Toast({ toast, onClose }) {
  if (!toast) return null;
  const tone = toast.type === "error" ? "border-red-500/40 text-red-200" : "border-emerald-500/40 text-emerald-200";
  return (
    <div role="status" className={`fixed bottom-6 left-1/2 z-50 flex -translate-x-1/2 animate-rise items-center gap-3 rounded-xl border bg-ink-800 px-4 py-3 text-sm shadow-2xl ${tone}`}>
      <span>{toast.message}</span>
      <button aria-label="Dismiss" className="text-slate-400 hover:text-white" onClick={onClose}>✕</button>
    </div>
  );
}
