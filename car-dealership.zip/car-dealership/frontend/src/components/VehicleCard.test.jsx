import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import VehicleCard from "./VehicleCard";

const car = { id: 1, make: "Toyota", model: "Camry", category: "Sedan", price: 28000, quantity: 3 };
const noop = () => {};
const props = { onPurchase: noop, onEdit: noop, onDelete: noop, onRestock: noop };

describe("VehicleCard", () => {
  it("enables purchase and fires callback when in stock", async () => {
    const onPurchase = vi.fn();
    render(<VehicleCard vehicle={car} {...props} onPurchase={onPurchase} />);
    const btn = screen.getByRole("button", { name: "Purchase" });
    expect(btn).toBeEnabled();
    await userEvent.click(btn);
    expect(onPurchase).toHaveBeenCalledWith(car);
  });

  it("disables purchase when quantity is zero", () => {
    render(<VehicleCard vehicle={{ ...car, quantity: 0 }} {...props} />);
    expect(screen.getByRole("button", { name: "Out of stock" })).toBeDisabled();
    expect(screen.getByText("Sold out")).toBeInTheDocument();
  });

  it("shows admin controls only for admins", () => {
    const { rerender } = render(<VehicleCard vehicle={car} {...props} isAdmin={false} />);
    expect(screen.queryByRole("button", { name: "Delete" })).toBeNull();
    rerender(<VehicleCard vehicle={car} {...props} isAdmin />);
    expect(screen.getByRole("button", { name: "Delete" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Edit" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Restock" })).toBeInTheDocument();
  });
});
