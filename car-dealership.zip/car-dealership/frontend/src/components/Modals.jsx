import { useState } from "react";

function Shell({ title, children, onClose, label }) {
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-black/70 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={label || title} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="w-full max-w-sm animate-rise rounded-2xl border border-ink-600 bg-ink-900 p-6 shadow-2xl">
        <h2 className="mb-3 font-display text-xl font-bold text-white">{title}</h2>
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog({ title, message, confirmLabel = "Confirm", danger, onConfirm, onClose }) {
  return (
    <Shell title={title} onClose={onClose}>
      <p className="text-sm text-slate-400">{message}</p>
      <div className="mt-6 flex justify-end gap-3">
        <button className="btn-ghost" onClick={onClose}>Cancel</button>
        <button className={danger ? "btn bg-red-500 text-white hover:bg-red-400" : "btn-primary"} onClick={onConfirm}>{confirmLabel}</button>
      </div>
    </Shell>
  );
}

/** Quantity prompt used for both purchase and restock. */
export function QuantityDialog({ title, message, max, confirmLabel, onConfirm, onClose }) {
  const [qty, setQty] = useState(1);
  const invalid = !Number.isInteger(qty) || qty < 1 || (max !== undefined && qty > max);
  return (
    <Shell title={title} onClose={onClose}>
      <p className="mb-4 text-sm text-slate-400">{message}</p>
      <label className="label" htmlFor="qty">Quantity</label>
      <input id="qty" type="number" min="1" max={max} className="input" value={qty} onChange={(e) => setQty(Number(e.target.value))} autoFocus />
      <div className="mt-6 flex justify-end gap-3">
        <button className="btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn-primary" disabled={invalid} onClick={() => onConfirm(qty)}>{confirmLabel}</button>
      </div>
    </Shell>
  );
}
