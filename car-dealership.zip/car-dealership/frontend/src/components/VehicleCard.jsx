import { formatPrice, stockStatus } from "../lib/format";

const TONES = {
  ok: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/30",
  low: "bg-amber-500/15 text-amber-300 ring-amber-500/30",
  out: "bg-red-500/15 text-red-300 ring-red-500/30",
};

function Placeholder({ make }) {
  return (
    <div className="grid h-full w-full place-items-center bg-gradient-to-br from-ink-700 to-ink-800 font-display text-6xl font-bold text-ink-600">
      {make?.[0]?.toUpperCase()}
    </div>
  );
}

export default function VehicleCard({ vehicle, isAdmin, busy, onPurchase, onEdit, onDelete, onRestock, index = 0 }) {
  const { label, tone } = stockStatus(vehicle.quantity);
  const soldOut = vehicle.quantity <= 0;

  return (
    <article className="group animate-rise overflow-hidden rounded-2xl border border-ink-700 bg-ink-900 transition hover:-translate-y-1 hover:border-ink-600 hover:shadow-2xl" style={{ animationDelay: `${Math.min(index, 12) * 40}ms` }}>
      <div className="relative aspect-[16/10] overflow-hidden bg-ink-800">
        <div className="absolute inset-0"><Placeholder make={vehicle.make} /></div>
        {vehicle.image_url ? (
          <img src={vehicle.image_url} alt={`${vehicle.make} ${vehicle.model}`} loading="lazy" className={`relative h-full w-full object-cover transition duration-500 group-hover:scale-105 ${soldOut ? "grayscale opacity-60" : ""}`}
            onError={(e) => { e.currentTarget.style.display = "none"; }} />
        ) : null}
        <span className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 backdrop-blur ${TONES[tone]}`}>{label}</span>
        <span className="absolute right-3 top-3 rounded-full bg-ink-950/70 px-2.5 py-1 text-xs font-medium text-slate-300 backdrop-blur">{vehicle.category}</span>
      </div>

      <div className="p-5">
        <p className="text-xs font-semibold uppercase tracking-widest text-accent">{vehicle.make}</p>
        <h3 className="font-display text-xl font-bold text-white">{vehicle.model}</h3>
        <p className="mt-2 font-display text-2xl font-semibold text-slate-100">{formatPrice(vehicle.price)}</p>

        <button className="btn-primary mt-4 w-full" disabled={soldOut || busy} onClick={() => onPurchase(vehicle)}>
          {soldOut ? "Out of stock" : "Purchase"}
        </button>

        {isAdmin && (
          <div className="mt-3 grid grid-cols-3 gap-2 border-t border-ink-700 pt-3">
            <button className="btn-ghost !px-2 !py-1.5 text-xs" onClick={() => onRestock(vehicle)}>Restock</button>
            <button className="btn-ghost !px-2 !py-1.5 text-xs" onClick={() => onEdit(vehicle)}>Edit</button>
            <button className="btn-danger !px-2 !py-1.5 text-xs" onClick={() => onDelete(vehicle)}>Delete</button>
          </div>
        )}
      </div>
    </article>
  );
}
