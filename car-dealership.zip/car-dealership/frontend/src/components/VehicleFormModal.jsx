import { useState } from "react";

const BLANK = { make: "", model: "", category: "", price: "", quantity: 1, image_url: "" };

/** Add / edit dialog. `vehicle` = existing record when editing. */
export default function VehicleFormModal({ vehicle, onClose, onSubmit }) {
  const [form, setForm] = useState(vehicle ? { ...BLANK, ...vehicle, image_url: vehicle.image_url ?? "" } : BLANK);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await onSubmit({
        make: form.make.trim(), model: form.model.trim(), category: form.category.trim(),
        price: Number(form.price), quantity: Number(form.quantity), image_url: form.image_url.trim() || null,
      });
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-black/70 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={vehicle ? "Edit vehicle" : "Add vehicle"} onClick={onClose}>
      <form onSubmit={submit} onClick={(e) => e.stopPropagation()} className="w-full max-w-lg animate-rise rounded-2xl border border-ink-600 bg-ink-900 p-6 shadow-2xl">
        <h2 className="mb-5 font-display text-2xl font-bold text-white">{vehicle ? "Edit vehicle" : "Add a vehicle"}</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="label" htmlFor="f-make">Make</label><input id="f-make" className="input" required value={form.make} onChange={set("make")} /></div>
          <div><label className="label" htmlFor="f-model">Model</label><input id="f-model" className="input" required value={form.model} onChange={set("model")} /></div>
          <div><label className="label" htmlFor="f-cat">Category</label><input id="f-cat" className="input" required placeholder="Sedan, SUV, Truck…" value={form.category} onChange={set("category")} /></div>
          <div><label className="label" htmlFor="f-price">Price (USD)</label><input id="f-price" type="number" min="0" step="any" className="input" required value={form.price} onChange={set("price")} /></div>
          <div><label className="label" htmlFor="f-qty">Quantity</label><input id="f-qty" type="number" min="0" step="1" className="input" required value={form.quantity} onChange={set("quantity")} /></div>
          <div><label className="label" htmlFor="f-img">Image URL (optional)</label><input id="f-img" type="url" className="input" value={form.image_url} onChange={set("image_url")} /></div>
        </div>
        {error && <p role="alert" className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</p>}
        <div className="mt-6 flex justify-end gap-3">
          <button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={busy}>{busy ? "Saving…" : vehicle ? "Save changes" : "Add vehicle"}</button>
        </div>
      </form>
    </div>
  );
}
