export const EMPTY_FILTERS = { make: "", model: "", category: "", min_price: "", max_price: "" };

export default function FilterBar({ filters, categories, onChange, onReset }) {
  const set = (k) => (e) => onChange({ ...filters, [k]: e.target.value });
  const active = Object.values(filters).some(Boolean);

  return (
    <form role="search" aria-label="Filter vehicles" onSubmit={(e) => e.preventDefault()} className="grid gap-3 rounded-2xl border border-ink-700 bg-ink-900/70 p-4 backdrop-blur sm:grid-cols-2 lg:grid-cols-6">
      <input aria-label="Make" className="input" placeholder="Make" value={filters.make} onChange={set("make")} />
      <input aria-label="Model" className="input" placeholder="Model" value={filters.model} onChange={set("model")} />
      <select aria-label="Category" className="input" value={filters.category} onChange={set("category")}>
        <option value="">All categories</option>
        {categories.map((c) => <option key={c} value={c}>{c}</option>)}
      </select>
      <input aria-label="Minimum price" className="input" type="number" min="0" placeholder="Min price" value={filters.min_price} onChange={set("min_price")} />
      <input aria-label="Maximum price" className="input" type="number" min="0" placeholder="Max price" value={filters.max_price} onChange={set("max_price")} />
      <button type="button" className="btn-ghost" disabled={!active} onClick={onReset}>Clear filters</button>
    </form>
  );
}
