/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Space Grotesk"', "ui-sans-serif", "system-ui", "sans-serif"],
        sans: ['"Inter"', "ui-sans-serif", "system-ui", "sans-serif"],
      },
      colors: {
        ink: { 950: "#0a0c10", 900: "#10141b", 800: "#171c26", 700: "#222938", 600: "#323c50" },
        accent: { DEFAULT: "#ff5a36", soft: "#ff7a5c", dim: "#c2432a" },
      },
      boxShadow: { glow: "0 10px 40px -12px rgba(255,90,54,.45)" },
      keyframes: { rise: { from: { opacity: 0, transform: "translateY(12px)" }, to: { opacity: 1, transform: "none" } } },
      animation: { rise: "rise .45s ease-out both" },
    },
  },
  plugins: [],
};
