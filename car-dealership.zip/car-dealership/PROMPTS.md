# PROMPTS.md — raw AI chat log

> Tool: Claude (Claude Code, model `claude-sonnet-5-5`). Logs below are verbatim, not summarised.
> **Owner action:** if you continue the project in other chats (Copilot, ChatGPT, etc.), paste those raw
> transcripts or public share links below so this file is a complete record.

## Session 1

**User:**

```
@AI_Kata_Car_Dealership_Inventory_System_V2.docx use python and give complete project
```

(The attached file was the kata brief: "TDD Kata: Car Dealership Inventory System" — FastAPI/Django/Node/Rails
backend with JWT auth, vehicle + inventory endpoints, React/Tailwind SPA, TDD commit history, AI co-author
trailers, README with "My AI Usage", test report, PROMPTS.md.)

**Assistant:** Built the full project in this session: FastAPI backend written test-first (red → green commits),
React + Tailwind frontend, seed data, README, test reports and screenshots.
