# Apex Motors — Car Dealership Inventory System

A full-stack inventory app built for the *TDD Kata: Car Dealership Inventory System*.

- **Backend:** Python 3.11+, FastAPI, SQLAlchemy 2, SQLite (persistent file DB; swap to PostgreSQL via `DATABASE_URL`), JWT auth, bcrypt.
- **Frontend:** React 18 (Vite), Tailwind CSS 3, HTML5/CSS3, Vitest + Testing Library.
- **Tests:** 46 backend tests (98 % coverage) + 10 frontend tests.

## Screenshots

| Login | Customer dashboard | Search |
|---|---|---|
| ![](docs/screenshots/01-login.png) | ![](docs/screenshots/03-dashboard-customer.png) | ![](docs/screenshots/04-search.png) |

| Purchase | Admin dashboard | Add vehicle |
|---|---|---|
| ![](docs/screenshots/05-purchase-dialog.png) | ![](docs/screenshots/07-dashboard-admin.png) | ![](docs/screenshots/08-admin-add-vehicle.png) |

| Register | Mobile |
|---|---|
| ![](docs/screenshots/02-register.png) | ![](docs/screenshots/09-mobile.png) |

> Vehicle photos load from Unsplash URLs in the seed data; if offline, a lettered placeholder is shown.

## Features

- Register / log in; JWT bearer tokens secure the API.
- **Roles:** the *first* account registered becomes `admin`; everyone after is `user`. (Seeding creates `admin@dealership.com` / `Admin123!` and `user@dealership.com` / `User1234!`.)
- Browse all vehicles; search by make, model, category (case-insensitive, partial) and price range.
- **Purchase** with a quantity prompt — button disabled when stock is 0. Stock is decremented with an atomic conditional `UPDATE`, so concurrent buyers can never oversell.
- Admin: add, edit, delete vehicles and restock.

### API

| Method | Path | Access |
|---|---|---|
| POST | `/api/auth/register`, `/api/auth/login` | public |
| GET | `/api/auth/me` | token |
| POST | `/api/vehicles` | token |
| GET | `/api/vehicles` (`?available_only=true`) | token |
| GET | `/api/vehicles/search?make&model&category&min_price&max_price` | token |
| GET | `/api/vehicles/{id}` | token |
| PUT | `/api/vehicles/{id}` | token (partial update) |
| DELETE | `/api/vehicles/{id}` | **admin** |
| POST | `/api/vehicles/{id}/purchase` `{quantity}` | token (409 if insufficient stock) |
| POST | `/api/vehicles/{id}/restock` `{quantity}` | **admin** |

Interactive docs: http://localhost:8000/docs

> Per the brief, only delete and restock are admin-only on the backend; the UI only *shows* add/edit/delete/restock to admins. To restrict add/update server-side too, add `dependencies=[Depends(require_admin)]` to those routes.

## Run locally

### Backend
```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # optional; defaults work out of the box
python seed.py                  # demo users + 8 vehicles
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev                     # http://localhost:5173 (proxies /api to :8000)
```
Set `VITE_API_URL` if the API is hosted elsewhere.

## Tests & report

```bash
cd backend  && python -m pytest --cov=app        # backend
cd frontend && npm test                          # frontend
```
Saved reports: [`docs/test-report.txt`](docs/test-report.txt) (46 passed, 98 % coverage) and [`docs/frontend-test-report.txt`](docs/frontend-test-report.txt) (10 passed).

## Architecture & design

```
backend/app
  main.py            app factory, CORS, lifespan (creates tables)
  routers/           thin HTTP layer (auth, vehicles)
  services/          business logic, no HTTP knowledge (SRP)
  deps.py            get_current_user / require_admin
  security.py        bcrypt + JWT helpers
  models.py schemas.py database.py config.py
frontend/src
  lib/api.js         fetch wrapper   context/AuthContext   pages/   components/
```
Routers → services → ORM keeps each layer independently testable (SOLID: single responsibility, dependency inversion through FastAPI's `get_db` override in tests).

## TDD workflow

Backend history follows red → green → refactor: each feature has a `test: … (red)` commit with failing tests followed by a `feat: … (green)` commit (`git log --oneline`).
Note: the frontend was written test-after (component tests added with it); the strict red/green discipline applies to the backend logic, as the brief emphasises.

## My AI Usage

**Tools:** Claude (Claude Code, Sonnet 5.5).

**How I used it:**
- Gave Claude the kata brief and asked for a complete Python project.
- Claude proposed the architecture, wrote the backend tests first, confirmed they failed, then implemented code to pass them; it also produced the React/Tailwind UI, seed script, README and screenshots via a headless browser.
- Claude ran the test suites and the live app to verify behaviour.

**Reflection:** *(edit this to be your own words before submitting — the interview will probe it.)* AI removed boilerplate and made strict TDD cheap to follow, but I should personally review every
decision: e.g. the "first user is admin" bootstrap, the choice to let any authenticated user add/update vehicles (per the brief), and the atomic-UPDATE purchase logic. Be ready to explain each.

See [PROMPTS.md](PROMPTS.md) for the raw chat log. Every AI-assisted commit carries a `Co-Authored-By` trailer.

## Deployment (optional)

Backend: any host that runs `uvicorn app.main:app` (Render/Railway/Fly); set `JWT_SECRET`, `DATABASE_URL`, `CORS_ORIGINS`. Frontend: `npm run build`, deploy `dist/` to Vercel/Netlify with `VITE_API_URL`.
